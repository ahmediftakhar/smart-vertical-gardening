package com.abc.smartverticalgardening

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
